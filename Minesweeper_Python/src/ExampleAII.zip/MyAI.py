# ==============================CS-199==================================
# FILE:			MyAI.py
#
# AUTHOR: 		Justin Chung
#
# DESCRIPTION:	This file contains the MyAI class. You will implement your
#				agent in this file. You will write the 'getAction' function,
#				the constructor, and any additional helper functions.
#
# NOTES: 		- MyAI inherits from the abstract AI class in AI.py.
#
#				- DO NOT MAKE CHANGES TO THIS FILE.
# ==============================CS-199==================================
import random
from AI import AI
from Action import Action


class MyAI( AI ):

        def __init__(self, rowDimension, colDimension, totalMines, startX, startY):
                self.__moveCount = 0
                self.__totalTiles = rowDimension * colDimension
                self.__totalMines = totalMines
                self.__checkedCoords = [(startX, startY)]
                self.__rowDimension = rowDimension
                self.__colDimension = colDimension
                self.__moveCount = 0
                self.__board = []
                self.__uncovered = []
                self.__flagged = []
                self.__lastAction = 1
                self.__currX = startX
                self.__currY = startY
                for i in range(0,self.__rowDimension):
                        init_row = []
                        for x in range(0, self.__colDimension):
                                init_row.append('.')
                        self.__board.append(init_row)
                self.__board[self.__currY][self.__currX] = 0
                self.__toDel = MyAI.adjacencyCheck(self, startX, startY, 0)
                self.__Over = False
                self.__uncoverCounter = 1
                self.__final = False
                
        def getAction(self, number: int) -> "Action Object":
                if(self.__moveCount >= 70):
                        return Action(AI.Action(0))
                #print("SIZE OF UNCOVERED: ",self.__uncoverCounter)
                if (self.__uncoverCounter == self.__totalTiles - self.__totalMines):
                        return Action(AI.Action(0))
                #START BY CLEARING EVERYTHING ADJACENT TO START COORDINATE
                if (len(self.__toDel) == 0 and self.__final == False):
                        #minimum_label = min([tup[0] for tup in self.__uncovered])
                        #print(minimum_label)
                        MyAI.getTiles(self, [0])#, minimum_label)
                #print("SIZE OF DEL1: ",len(self.__toDel))
                if (len(self.__toDel) > 0 or self.__final == True):
                        return MyAI.makeMove(self,number)
                
                else:
                        #print("FINAL COORDS ARE: ",(self.__currX+1,self.__currY+1))
                        #print("SIZE OF TODEL BEFORE: ",len(self.__toDel))
                        self.__board[self.__currY][self.__currX] = number
                        self.__uncovered.append((number,self.__currX,self.__currY))
                        #minimum_label = min([tup[0] for tup in self.__uncovered])
                        labels = sorted(list({tup[0] for tup in self.__uncovered}))
                        #print(minimum_label)
                        MyAI.getTiles(self, labels)
                        #print("SIZE OF TODEL AFTER: ",len(self.__toDel))
                        if(len(self.__toDel)>0):
                                return MyAI.makeMove(self,number)
                        #for i in self.__uncovered:
                                #print((i[1]+1,i[2]+1))
                        #print(self.__uncovered)
                        #print(self.__board)
                        self.__Over = True
                        return Action(AI.Action(0))

        def getTiles(self, labels):
                #print("SIZE OF UNCOVERED: ",len(self.__uncovered))
                #print(self.__uncovered)
                while(len(labels)>0 and len(self.__toDel) == 0):
                        min_label = labels[0]
                        del labels[0]
                        for index, tup in enumerate(self.__uncovered):
                                #print(tup)
                                toDel = []
                                if (tup[0] == min_label):
                                        #print("DELETING: ",(tup[1]+1,tup[2]+1)," FROM")
                                        #for i in self.__uncovered:
                                                #print((i[1]+1,i[2]+1))
                                        currX = tup[1]
                                        currY = tup[2]
                                        self.__toDel = MyAI.adjacencyCheck(self, currX, currY, min_label)
                                        toDel.append(index)
                                        #print("SIZE OF LIST: ",len(self.__toDel))
                                        if (len(self.__toDel) == 0):
                                                continue
                                        break
                for index in toDel:
                        del self.__uncovered[index]

        def makeMove(self,number):
                if self.__final == False:
                        #print("HEEERE")
                        coord = self.__toDel[0]
                        #print("HEEERE")
                        del self.__toDel[0]
                        #print("HEEERE")
                        #print("SIZE OF DEL2: ",len(self.__toDel))
                        if (len(self.__toDel) == 0):
                                self.__final = True
                                #print("SET TO TRUE?: ",self.__final)
                if(self.__final == True):
                        #print("AT TRUE ADDED: ",(number,self.__currX+1, self.__currY+1))
                        if((number,self.__currX, self.__currY) not in self.__uncovered):
                                self.__board[self.__currY][self.__currX] = number
                                self.__uncovered.append((number,self.__currX, self.__currY))
                        self.__final = False
                if (self.__moveCount > 0):
                        if((number, self.__currX, self.__currY) not in self.__uncovered):
                                self.__board[self.__currY][self.__currX] = number
                                self.__uncovered.append((number,self.__currX, self.__currY))
                        #print("UNCOVERED: ", (number,self.__currX + 1, self.__currY + 1))
                        #print("SIZE OF UNCOVEREDLIST: ",len(self.__uncovered))
                self.__currX = coord[0]
                self.__currY = coord[1]
                self.__moveCount += 1
                #print("ABOUT TO UNCOVER: ",(coord[0]+1,coord[1]+1))
                self.__uncoverCounter += 1
                return Action(AI.Action(1), coord[0],coord[1])


        def adjacencyCheck(self, x,y, label):
                #print("Adjacency Check for: ", x + 1, y + 1)
                AList = [(x-1,y),(x-1,y-1),(x-1,y+1),(x,y-1),
                (x,y+1),(x+1,y-1),(x+1,y),(x+1,y+1)]
                rList = []
                if label == 0:
                        for index, c in enumerate(AList):
                                if (c[0] < 0 or c[1] < 0):
                                        continue
                                if (c[0] > self.__rowDimension  - 1 or c[1] > self.__colDimension - 1):
                                        continue
                                if (c in self.__checkedCoords):
                                        #print("ALREADY FOR ",(x,y))
                                        continue
                                self.__checkedCoords.append(c)
                                rList.append(c)
                else:
                        bomb_tiles = []
                        covered_tiles = []
                        for tup in AList:
                                if (tup[0] < 0 or tup[1] < 0):
                                        continue
                                if (tup[0] > self.__rowDimension  - 1 or tup[1] > self.__colDimension - 1):
                                        continue
                                if self.__board[tup[1]][tup[0]] == 'B':
                                        bomb_tiles.append(tup)
                        for tup in AList:
                                if (tup[0] < 0 or tup[1] < 0):
                                        continue
                                if (tup[0] > self.__rowDimension  - 1 or tup[1] > self.__colDimension - 1):
                                        continue
                                if self.__board[tup[1]][tup[0]] == '.':
                                        covered_tiles.append(tup)
                        #bomb_tiles = [tup for tup in AList if self.__board[tup[1]][tup[0]] == 'B']
                        #covered_tiles = [tup for tup in AList if self.__board[tup[1]][tup[0]] == '.']
                        if len(bomb_tiles) == label:
                                for tup in covered_tiles:
                                        self.__checkedCoords.append(tup)
                                        rList.append(tup)
                        elif len(covered_tiles) + len(bomb_tiles) == label:
                                for tup in covered_tiles:
                                        self.__board[tup[1]][tup[0]] = 'B'

                #print("SIZE OF RLIST: ",len(rList))
                return rList

        
